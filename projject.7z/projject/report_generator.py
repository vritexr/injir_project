from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from datetime import datetime
import os

from models import Program, PassingScore
from calculator import get_admitted_applicants, get_statistics



_font_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")
_font_path = os.path.join(_font_dir, "DejaVuSans.ttf")
if os.path.exists(_font_path):
    pdfmetrics.registerFont(TTFont("DejaVuSans", _font_path))
else:
    
    _font_path_fallback = "fonts/DejaVuSans.ttf"
    if os.path.exists(_font_path_fallback):
        pdfmetrics.registerFont(TTFont("DejaVuSans", _font_path_fallback))


def generate_pdf_report(report_date: datetime.date):
    reports_dir = 'data/reports'
    os.makedirs(reports_dir, exist_ok=True)
    
    filename = f"{reports_dir}/report_{report_date.strftime('%Y%m%d')}.pdf"
    
    doc = SimpleDocTemplate(filename, pagesize=A4)
    elements = []
    
    styles = getSampleStyleSheet()


    normal_style = ParagraphStyle(
        "CustomNormal",
        parent=styles["Normal"],
        fontName="DejaVuSans",
        fontSize=10,
    )

    title_style = ParagraphStyle(
        "CustomTitle",
        parent=styles["Heading1"],
        fontName="DejaVuSans",
        fontSize=16,
        spaceAfter=30,
    )

    heading2_style = ParagraphStyle(
        "CustomHeading2",
        parent=styles["Heading2"],
        fontName="DejaVuSans",
    )

    heading3_style = ParagraphStyle(
        "CustomHeading3",
        parent=styles["Heading3"],
        fontName="DejaVuSans",
    )
    
    elements.append(Paragraph(f"Отчет по поступлению на {report_date}", title_style))
    elements.append(Paragraph(f"Сформирован: {datetime.now().strftime('%Y-%m-%d %H:%M')}", normal_style))
    elements.append(Spacer(1, 20))
    
    elements.append(Paragraph("Проходные баллы по образовательным программам:", heading2_style))
    
    programs = Program.query.all()
    passing_data = []
    
    for program in programs:
        score = PassingScore.query.filter_by(
            program_id=program.id,
            date=report_date
        ).first()
        
        passing_data.append([
            str(program.name),
            str(program.budget_places),
            f"{score.score if score and score.score else 'НЕДОБОР'}"
        ])
    
    if passing_data:
        table = Table([["Программа", "Бюджетных мест", "Проходной балл"]] + passing_data)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("FONTNAME", (0, 0), (-1, -1), "DejaVuSans"),
            ("FONTSIZE", (0, 0), (-1, 0), 12),
            ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
            ("BACKGROUND", (0, 1), (-1, -1), colors.beige),
            ("GRID", (0, 0), (-1, -1), 1, colors.black),
        ]))
        elements.append(table)
        elements.append(Spacer(1, 20))

    
    try:
        from reportlab.graphics.shapes import Drawing
        from reportlab.graphics.charts.lineplots import LinePlot

        all_dates = [
            row[0] for row in
            PassingScore.query.with_entities(PassingScore.date)
            .filter(PassingScore.date <= report_date)
            .distinct()
            .order_by(PassingScore.date)
            .all()
        ]
        unique_dates = all_dates[-4:] if len(all_dates) > 4 else all_dates
        if unique_dates:
            programs_list = Program.query.order_by(Program.id).all()
            
            data_series = []
            y_max = 0
            for program in programs_list:
                points = []
                for j, d in enumerate(unique_dates):
                    ps = PassingScore.query.filter_by(
                        program_id=program.id, date=d
                    ).first()
                    val = ps.score if ps and ps.score is not None else 0
                    v = float(val)
                    if v > y_max:
                        y_max = v
                    points.append((j, v))
                data_series.append(points)

            drawing = Drawing(450, 220)
            lp = LinePlot()
            lp.x = 50
            lp.y = 30
            lp.height = 160
            lp.width = 380
            lp.data = data_series
            lp.joinedLines = 1
            lp.strokeColor = colors.black
            lp.xValueAxis.valueMin = 0
            lp.xValueAxis.valueMax = max(len(unique_dates) - 1, 1)
            date_labels = [d.strftime('%d.%m') for d in unique_dates]
            lp.xValueAxis.labelTextFormat = lambda idx, dl=date_labels: dl[int(idx)] if 0 <= int(idx) < len(dl) else str(int(idx))
            lp.yValueAxis.valueMin = 0
            lp.yValueAxis.valueMax = max(y_max * 1.1, 10)
            if hasattr(lp.xValueAxis.labels, 'fontName'):
                lp.xValueAxis.labels.fontName = 'DejaVuSans'
            if hasattr(lp.yValueAxis.labels, 'fontName'):
                lp.yValueAxis.labels.fontName = 'DejaVuSans'
            drawing.add(lp)
            elements.append(Paragraph("Динамика проходного балла на ОП по дням:", heading2_style))
            elements.append(drawing)
            elements.append(Spacer(1, 20))
    except Exception:  
        elements.append(Paragraph("Динамика проходного балла (график не построен): см. данные выше.", normal_style))
        elements.append(Spacer(1, 10))
    
    elements.append(Paragraph("Зачисленные абитуриенты:", heading2_style))
    
    admitted = get_admitted_applicants(report_date)
    
    for program_code, applicants in admitted.items():
        program = Program.query.filter_by(code=program_code).first()
        if not program:
            continue
            
        elements.append(Paragraph(f"{program.name}:", heading3_style))
        
        if not applicants:
            elements.append(Paragraph("Нет зачисленных абитуриентов", normal_style))
        else:
            app_data = [["ID абитуриента", "Сумма баллов"]]
            for app in applicants:
                app_data.append([str(app['id']), str(app['score'])])
            
            table = Table(app_data)
            table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
                ("FONTNAME", (0, 0), (-1, -1), "DejaVuSans"),
                ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("FONTSIZE", (0, 0), (-1, -1), 10),
            ]))
            elements.append(table)
        
        elements.append(Spacer(1, 10))
    
    elements.append(Paragraph("Статистика по программам:", heading2_style))
    
    stats = get_statistics(report_date)
    
    for program_code, program_stats in stats.items():
        program = Program.query.filter_by(code=program_code).first()
        if not program:
            continue
            
        elements.append(Paragraph(f"{program.name}:", heading3_style))
        
        stat_table = [
            ["Показатель", "Значение"],
            ["Общее количество заявлений", str(program_stats['total_applications'])],
            ["Бюджетных мест", str(program_stats['budget_places'])],
            ["Зачислено", str(program_stats['total_admitted'])],
            ["Заявлений 1-го приоритета", str(program_stats['priorities']['priority_1'])],
            ["Заявлений 2-го приоритета", str(program_stats['priorities']['priority_2'])],
            ["Заявлений 3-го приоритета", str(program_stats['priorities']['priority_3'])],
            ["Заявлений 4-го приоритета", str(program_stats['priorities']['priority_4'])],
            ["Зачислено 1-го приоритета", str(program_stats['admitted_by_priority']['admitted_1'])],
            ["Зачислено 2-го приоритета", str(program_stats['admitted_by_priority']['admitted_2'])],
            ["Зачислено 3-го приоритета", str(program_stats['admitted_by_priority']['admitted_3'])],
            ["Зачислено 4-го приоритета", str(program_stats['admitted_by_priority']['admitted_4'])],
        ]
        
        table = Table(stat_table)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.lightblue),
            ("FONTNAME", (0, 0), (-1, -1), "DejaVuSans"),
            ("GRID", (0, 0), (-1, -1), 1, colors.grey),
        ]))
        elements.append(table)
        elements.append(Spacer(1, 10))
    
    doc.build(elements)
    
    return filename