
from app import app
from models import db, Program

with app.app_context():
    
    db.create_all()
    
    
    programs = Program.query.all()
    
    if not programs:
        print("Добавляем образовательные программы...")
        
        programs_data = [
            {
                'code': 'ПМ',
                'name': 'Прикладная математика',
                'full_name': 'Прикладная математика',
                'budget_places': 40
            },
            {
                'code': 'ИВТ',
                'name': 'Информатика и вычислительная техника',
                'full_name': 'Информатика и вычислительная техника',
                'budget_places': 50
            },
            {
                'code': 'ИТСС',
                'name': 'Инфокоммуникационные технологии',
                'full_name': 'Инфокоммуникационные технологии и системы связи',
                'budget_places': 30
            },
            {
                'code': 'ИБ',
                'name': 'Информационная безопасность',
                'full_name': 'Информационная безопасность',
                'budget_places': 20
            }
        ]
        
        for prog_data in programs_data:
            program = Program(
                code=prog_data['code'],
                name=prog_data['name'],
                full_name=prog_data['full_name'],
                budget_places=prog_data['budget_places']
            )
            db.session.add(program)
        
        db.session.commit()
        print("Программы добавлены!")
    else:
        print("Программы уже существуют:")
        for p in programs:
            print(f"  {p.code}: {p.name} ({p.budget_places} мест)")
    
    print(f"Всего программ: {len(programs)}")