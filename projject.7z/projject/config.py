import os


basedir = os.path.dirname(os.path.abspath(__file__))

class Config:
    
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-key-change-in-production'
    
    
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(basedir, 'instance', 'admission.db')
    
    SQLALCHEMY_ENGINE_OPTIONS = {'connect_args': {'timeout': 30}}
    
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
   
    UPLOAD_FOLDER = os.path.join(basedir, 'uploads')
    ALLOWED_EXTENSIONS = {'csv', 'xlsx'}
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024
    
    @staticmethod
    def init_app(app):
        """Создаем необходимые папки"""
      
        if not os.path.exists(Config.UPLOAD_FOLDER):
            os.makedirs(Config.UPLOAD_FOLDER)
            print(f"Создана папка загрузок: {Config.UPLOAD_FOLDER}")
        
   
        db_path = Config.SQLALCHEMY_DATABASE_URI.replace('sqlite:///', '')
        print(f"База данных будет создана в: {db_path}")