from flask import Flask, render_template, request, jsonify, send_file, flash, redirect, url_for
from config import Config
from database import init_db
from models import db, Applicant, Program, PassingScore, AdmissionReport
from data_processor import DataProcessor
from calculator import calculate_passing_scores
from report_generator import generate_pdf_report
from datetime import datetime
import json
import io
import pandas as pd

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)

with app.app_context():
    init_db(app)

@app.route('/')
def index():
    programs = Program.query.all()
    latest_scores = {}
    
    for program in programs:
        latest_score = PassingScore.query.filter_by(program_id=program.id)\
            .order_by(PassingScore.date.desc())\
            .first()
        latest_scores[program.code] = latest_score
    
    return render_template('index.html', 
                         programs=programs,
                         latest_scores=latest_scores)

def _read_uploaded_file(f):
    """Прочитать один загруженный файл в DataFrame (CSV или XLSX)."""
    f.stream.seek(0)
    if f.filename.lower().endswith('.csv'):
        raw = f.stream.read()
        for enc in ('utf-8-sig', 'utf-8', 'cp1251'):
            try:
                return pd.read_csv(io.StringIO(raw.decode(enc)))
            except (UnicodeDecodeError, Exception):
                continue
        return pd.read_csv(io.StringIO(raw.decode('utf-8', errors='ignore')))
    f.stream.seek(0)
    return pd.read_excel(f.stream)


@app.route('/upload', methods=['GET', 'POST'])
def upload_data():
    if request.method == 'POST':
        files = request.files.getlist('files')
        valid_files = [f for f in files if f and f.filename and allowed_file(f.filename)]
        if not valid_files:
            flash('Выберите один или несколько файлов (CSV или XLSX).')
            return redirect(request.url)
        date_str = request.form.get('upload_date')
        if not date_str:
            flash('Укажите дату списка.')
            return redirect(request.url)
        upload_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        processor = DataProcessor(db)
        try:
            if len(valid_files) == 1:
                result = processor.process_file(valid_files[0], upload_date)
            else:
                
                dfs = []
                for f in valid_files:
                    df = _read_uploaded_file(f)
                    df.columns = [str(c).strip() for c in df.columns]
                    dfs.append(df)
                combined = pd.concat(dfs, ignore_index=True)
                if 'ID' in combined.columns and 'Программа' in combined.columns:
                    combined = combined.drop_duplicates(subset=['ID', 'Программа'], keep='last')
                buf = io.BytesIO()
                combined.to_csv(buf, index=False, encoding='utf-8-sig')
                buf.seek(0)
                class MergedFile:
                    filename = 'combined.csv'
                    stream = buf
                result = processor.process_file(MergedFile(), upload_date)
            calculate_passing_scores(upload_date)
            flash(f'Обработано файлов: {len(valid_files)}. Добавлено: {result["added"]}, '
                  f'обновлено: {result["updated"]}, удалено: {result["deleted"]}.')
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка при обработке: {str(e)}')
        return redirect(url_for('analysis'))
    return render_template('upload.html')

@app.route('/analysis')
def analysis():
    programs = Program.query.all()
    dates = db.session.query(Applicant.upload_date).distinct().order_by(Applicant.upload_date).all()
    dates = [d[0] for d in dates]
    
    analysis_data = {}
    for program in programs:
        program_data = {}
        for date in dates:
            scores = PassingScore.query.filter_by(
                program_id=program.id,
                date=date
            ).first()
            if scores:
                program_data[date] = {
                    'score': scores.score,
                    'status': scores.status
                }
        analysis_data[program.code] = program_data
    
    return render_template('analysis.html',
                         programs=programs,
                         dates=dates,
                         analysis_data=analysis_data)

@app.route('/visualization')
def visualization():
    """Визуализация данных"""
    programs = Program.query.all()
    available_dates = [
        d[0] for d in db.session.query(Applicant.upload_date)
        .distinct().order_by(Applicant.upload_date.desc()).all()
    ]
    default_date = available_dates[0] if available_dates else None

    
    chart_data = {}
    for program in programs:
        scores = PassingScore.query.filter_by(program_id=program.id)\
            .order_by(PassingScore.date)\
            .all()
        
        chart_data[program.code] = {
            'dates': [score.date.strftime('%Y-%m-%d') for score in scores],
            'scores': [score.score if score.score else 0 for score in scores],
            'statuses': [score.status for score in scores]
        }
    
    chart_data_json = json.dumps(chart_data)
    
    distribution_stats = {}
    for program in programs:
        count = Applicant.query.filter_by(program_id=program.id).count()
        distribution_stats[program.code] = {
            'total_applications': count,
            'with_consent': Applicant.query.filter_by(
                program_id=program.id, consent=True
            ).count()
        }
    
    programs_data = []
    for program in programs:
        programs_data.append({
            'code': program.code,
            'name': program.name,
            'budget_places': program.budget_places
        })
    
    return render_template('visualization.html',
                         programs=programs,
                         chart_data_json=chart_data_json,
                         programs_data_json=json.dumps(programs_data),
                         distribution_stats_json=json.dumps(distribution_stats),
                         available_dates=available_dates,
                         default_date=default_date)
    
@app.route('/reports')
def reports():
    # Все даты с данными (по возрастанию: 01.08, 02.08, 03.08, 04.08) — отчёт можно сформировать по любой
    available_dates = [
        d[0] for d in db.session.query(Applicant.upload_date)
        .distinct().order_by(Applicant.upload_date).all()
    ]
    default_date = available_dates[-1] if available_dates else None  # по умолчанию последняя (актуальная) дата

    if request.args.get('generate'):
        date_str = request.args.get('report_date')
        if not date_str:
            flash('Укажите дату отчёта')
            return redirect(url_for('reports'))
        try:
            report_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            flash('Неверный формат даты. Используйте ГГГГ-ММ-ДД.')
            return redirect(url_for('reports'))
        
        if report_date not in available_dates:
            if not available_dates:
                flash('В системе нет загруженных данных. Сначала загрузите файл на странице «Загрузка данных».')
            else:
                dates_str = ', '.join(d.strftime('%d.%m.%Y') for d in available_dates)
                flash(f'По дате {report_date.strftime("%d.%m.%Y")} данных нет. Выберите одну из дат с данными: {dates_str}')
            return redirect(url_for('reports'))
        try:
            pdf_path = generate_pdf_report(report_date)
            return send_file(pdf_path, as_attachment=True)
        except Exception as e:
            flash(f'Ошибка при формировании отчёта: {str(e)}')
            return redirect(url_for('reports'))

    available_dates_str = [d.strftime('%d.%m.%Y') for d in available_dates]
    return render_template('reports.html',
                         available_dates=available_dates,
                         available_dates_str=available_dates_str,
                         default_date=default_date)

@app.route('/api/applicants')
def get_applicants():
    program_code = request.args.get('program')
    date = request.args.get('date')
    sort_by = request.args.get('sort', 'total_score')
    order = request.args.get('order', 'desc')
    consent = request.args.get('consent')  # 'true', 'false' или None
    applicant_id = request.args.get('applicant_id', '').strip()  # поиск по ID
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 25, type=int)
    per_page = min(max(per_page, 1), 100)
    
    query = Applicant.query
    
    if program_code and program_code != 'all':
        program = Program.query.filter_by(code=program_code).first()
        if program:
            query = query.filter_by(program_id=program.id)
    
    if date:
        query = query.filter_by(upload_date=datetime.strptime(date, '%Y-%m-%d').date())

    if consent == 'true':
        query = query.filter_by(consent=True)
    elif consent == 'false':
        query = query.filter_by(consent=False)
    

    if applicant_id:
        try:
            aid = int(applicant_id)
            query = query.filter_by(applicant_id=aid)
        except ValueError:
            query = query.filter(Applicant.id == -1)  # пустой результат
    
    if sort_by == 'total_score':
        query = query.order_by(Applicant.total_score.desc() if order == 'desc' 
                              else Applicant.total_score.asc())
    
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    applicants = pagination.items
    
    result = []
    for app in applicants:
        result.append({
            'id': app.applicant_id,
            'consent': 'Да' if app.consent else 'Нет',
            'priority': app.priority_1,
            'physics': app.physics_score,
            'russian': app.russian_score,
            'math': app.math_score,
            'achievements': app.achievements_score,
            'total': app.total_score,
            'program': app.program.code if app.program else 'N/A'
        })
    
    return jsonify({
        'items': result,
        'total': pagination.total,
        'page': page,
        'per_page': per_page,
        'pages': pagination.pages
    })


@app.route('/api/passing_scores_by_date')
def passing_scores_by_date():
    """Проходные баллы и количество мест на указанную дату (для отображения в GUI)."""
    date_str = request.args.get('date')
    if not date_str:
        latest_dates = db.session.query(
            PassingScore.date
        ).distinct().order_by(PassingScore.date.desc()).limit(1).all()
        target_date = latest_dates[0][0] if latest_dates else None
    else:
        try:
            target_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'date': None, 'time': None, 'programs': []})
    if not target_date:
        return jsonify({'date': None, 'date_display': None, 'time': datetime.now().strftime('%H:%M'), 'programs': []})
    programs = Program.query.all()
    out = []
    for p in programs:
        ps = PassingScore.query.filter_by(program_id=p.id, date=target_date).first()
        out.append({
            'code': p.code,
            'name': p.name,
            'budget_places': p.budget_places,
            'passing_score': ps.score if ps and ps.score is not None else None,
            'status': (ps.status if ps else None) or 'NOT_ENOUGH',
        })
    return jsonify({
        'date': target_date.strftime('%Y-%m-%d'),
        'date_display': target_date.strftime('%d.%m.%Y'),
        'time': datetime.now().strftime('%H:%M'),
        'programs': out,
    })


@app.route('/manage-data', methods=['GET', 'POST'])
def manage_data():
    if request.method == 'POST':
        action = request.form.get('action')
        date_str = request.form.get('date')
        
        if action == 'delete_applicants' and date_str:
            try:
                date = datetime.strptime(date_str, '%Y-%m-%d').date()
                
                deleted_applicants = Applicant.query.filter_by(upload_date=date).delete()
                deleted_scores = PassingScore.query.filter_by(date=date).delete()
                
                db.session.commit()
                flash(f'Удалено {deleted_applicants} записей абитуриентов и {deleted_scores} проходных баллов за {date}')
                
            except Exception as e:
                flash(f'Ошибка при удалении: {str(e)}')
                db.session.rollback()
                
        elif action == 'reset_programs':
            try:
                Program.query.delete()
                
                programs_data = [
                    {'code': 'ПМ', 'name': 'Прикладная математика', 'budget_places': 40},
                    {'code': 'ИВТ', 'name': 'Информатика и вычислительная техника', 'budget_places': 50},
                    {'code': 'ИТСС', 'name': 'Инфокоммуникационные технологии', 'budget_places': 30},
                    {'code': 'ИБ', 'name': 'Информационная безопасность', 'budget_places': 20}
                ]
                
                for prog in programs_data:
                    program = Program(
                        code=prog['code'],
                        name=prog['name'],
                        budget_places=prog['budget_places']
                    )
                    db.session.add(program)
                
                db.session.commit()
                flash('Программы сброшены к исходным значениям')
                
            except Exception as e:
                flash(f'Ошибка при сбросе программ: {str(e)}')
                db.session.rollback()
                
        elif action == 'delete_all':
            try:
                if request.form.get('confirm') == 'yes':
                    deleted_applicants = Applicant.query.delete()
                    deleted_scores = PassingScore.query.delete()
                    
                    db.session.commit()
                    flash(f'Удалено {deleted_applicants} абитуриентов и {deleted_scores} проходных баллов. Программы сохранены.')
                else:
                    flash('Удаление всех данных отменено')
                    
            except Exception as e:
                flash(f'Ошибка при удалении всех данных: {str(e)}')
                db.session.rollback()
    
    dates = db.session.query(Applicant.upload_date).distinct().order_by(Applicant.upload_date.desc()).all()
    dates = [d[0] for d in dates]
    
    stats = {
        'total_applicants': Applicant.query.count(),
        'total_programs': Program.query.count(),
        'total_scores': PassingScore.query.count(),
        'available_dates': dates
    }
    
    return render_template('manage_data.html', 
                         stats=stats,
                         dates=dates)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

if __name__ == '__main__':
    app.run(debug=True)