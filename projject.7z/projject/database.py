from flask_sqlalchemy import SQLAlchemy
from models import db, Program

def init_db(app):
    """Инициализация базы данных"""
    with app.app_context():
        db.create_all()
        try:
            db.session.execute(db.text('PRAGMA journal_mode=WAL'))
            db.session.commit()
        except Exception:
            pass
        
        try:
            db.session.execute(db.text(
                'CREATE UNIQUE INDEX IF NOT EXISTS uq_applicant_program '
                'ON applicants (applicant_id, program_id)'
            ))
            db.session.commit()
        except Exception:
            db.session.rollback()
        print("Таблицы созданы")
        
       
        if Program.query.count() == 0:
            print("Инициализация базы данных: добавление программ...")
            
            programs = [
                Program(
                    code='ПМ',
                    name='Прикладная математика',
                    full_name='Прикладная математика',
                    budget_places=40
                ),
                Program(
                    code='ИВТ',
                    name='Информатика и вычислительная техника',
                    full_name='Информатика и вычислительная техника',
                    budget_places=50
                ),
                Program(
                    code='ИТСС',
                    name='Инфокоммуникационные технологии',
                    full_name='Инфокоммуникационные технологии и системы связи',
                    budget_places=30
                ),
                Program(
                    code='ИБ',
                    name='Информационная безопасность',
                    full_name='Информационная безопасность',
                    budget_places=20
                )
            ]
            
            for program in programs:
                db.session.add(program)
            
            db.session.commit()
            print("Образовательные программы добавлены в БД")
        else:
            print(f"В БД уже есть {Program.query.count()} программ")