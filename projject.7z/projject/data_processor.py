import pandas as pd
import io
import chardet
import re
from models import Applicant, Program, db
from datetime import datetime

BATCH_SIZE = 400  # коммит каждые N записей, чтобы не держать долгую блокировку SQLite


class DataProcessor:
    
    def __init__(self, database):
        self.db = database
        
    def process_file(self, file, upload_date):
        print(f"=== НАЧАЛО ОБРАБОТКИ ФАЙЛА ===")
        print(f"Файл: {file.filename}")
        print(f"Дата: {upload_date}")
        try:
            self._check_programs_in_db()
            
            df = self._read_file(file)
            print(f"Файл прочитан, строк: {len(df)}")
            
            df = self._clean_dataframe(df)
            self._validate_dataframe(df)
            df = self._deduplicate_by_id(df)
            
            # Одна запись на (applicant_id, программа) по всей БД: совпадающие — обновляем, дату ставим текущую.
            existing_all, keys_for_this_date = self._get_existing_keys(upload_date)
            print(f"Всего записей (ID, программа) в БД: {len(existing_all)}, из них на дату {upload_date}: {len(keys_for_this_date)}")
            
            added, updated, deleted_count, errors = self._process_records(df, upload_date, existing_all, keys_for_this_date)
            
            self.db.session.commit()
            print("Изменения сохранены в БД")
        except Exception as e:
            self.db.session.rollback()
            print(f"Ошибка при обработке: {e}")
            raise
        
        print(f"\n=== РЕЗУЛЬТАТ ОБРАБОТКИ ===")
        print(f"Добавлено: {added}")
        print(f"Обновлено: {updated}")
        print(f"Удалено: {deleted_count}")
        
        if errors:
            print(f"Ошибок: {len(errors)}")
            for error in errors[:5]:
                print(f"  - {error}")
        
        return {
            'added': added,
            'updated': updated,
            'deleted': deleted_count,
            'errors': errors if errors else []
        }
    
    def _check_programs_in_db(self):
        try:
            programs = Program.query.all()
            print(f"Программ в БД: {len(programs)}")
            for p in programs:
                print(f"  '{p.code}': {p.name} (ID: {p.id})")
        except Exception as e:
            print(f"Ошибка при проверке программ в БД: {e}")
    
    def _read_file(self, file):
        if file.filename.endswith('.csv'):
            return self._read_csv(file)
        elif file.filename.endswith('.xlsx'):
            df = pd.read_excel(file.stream)
            print(f"Excel файл прочитан успешно")
            return df
        else:
            raise ValueError("Поддерживаются только CSV и Excel файлы")
    
    def _read_csv(self, file):
        raw_data = file.stream.read()
        
        try:
            decoded = raw_data.decode('utf-8-sig')
            df = pd.read_csv(io.StringIO(decoded))
            print("CSV прочитан с кодировкой utf-8-sig")
            return df
        except UnicodeDecodeError:
            pass
        
        try:
            decoded = raw_data.decode('cp1251')
            df = pd.read_csv(io.StringIO(decoded))
            print("CSV прочитан с кодировкой cp1251")
            return df
        except UnicodeDecodeError:
            pass
        
        try:
            result = chardet.detect(raw_data)
            encoding = result['encoding']
            confidence = result['confidence']
            print(f"Автоопределена кодировка: {encoding} (уверенность: {confidence})")
            
            if encoding:
                decoded = raw_data.decode(encoding)
                df = pd.read_csv(io.StringIO(decoded))
                print(f"CSV прочитан с автоопределенной кодировкой {encoding}")
                return df
        except Exception as e:
            print(f"Ошибка автоопределения кодировки: {e}")
            pass
        
        try:
            decoded = raw_data.decode('utf-8', errors='ignore')
            df = pd.read_csv(io.StringIO(decoded))
            print("CSV прочитан с игнорированием ошибок")
            return df
        except Exception as e:
            raise ValueError(f"Не удалось прочитать CSV файл: {str(e)}")
    
    def _clean_dataframe(self, df):
        df = df.copy()
        
        df.columns = [str(col).strip() for col in df.columns]
        print(f"Очищенные названия колонок: {list(df.columns)}")
        
        for col in df.columns:
            if df[col].dtype == 'object':
                df[col] = df[col].astype(str).str.strip()
        
        if 'Согласие' in df.columns:
            print(f"Обработка колонки 'Согласие'...")
            df['Согласие'] = df['Согласие'].apply(self._parse_consent_value)
            print(f"   Преобразованные значения: {df['Согласие'].unique()}")
        
        return df
    
    def _parse_consent_value(self, value):
        if pd.isna(value):
            return 0
        
        value_str = str(value).strip()
        
        try:
            return int(value_str)
        except ValueError:
            pass
        
        value_lower = value_str.lower()
        
        
        if any(x in value_lower for x in ['1', 'да', 'true', 'yes', '+']):
            return 1
        
        if any(x in value_lower for x in ['0', 'нет', 'false', 'no', '-']):
            return 0
        
        numbers = re.findall(r'\d+', value_str)
        if numbers:
            return int(numbers[0])
        
        return 0
    
    def _validate_dataframe(self, df):
        required_columns = ['ID', 'Согласие', 'Приоритет', 'Программа', 
                          'Физика', 'Русский', 'Математика', 'Достижения', 'Сумма']
        
        missing = [col for col in required_columns if col not in df.columns]
        if missing:
            raise ValueError(f"Отсутствуют обязательные колонки: {', '.join(missing)}")
        
        print("Структура файла валидна")

    def _deduplicate_by_id(self, df):
        """Убираем дубликаты по (ID, Программа) — оставляем последнюю строку."""
        before = len(df)
        df = df.drop_duplicates(subset=['ID', 'Программа'], keep='last').reset_index(drop=True)
        if before > len(df):
            print(f"Удалено дубликатов по (ID, Программа): {before - len(df)}")
        return df
    
    def _get_existing_keys(self, upload_date):
        """Возвращает: (1) все (applicant_id, program_id) в БД; (2) из них с датой upload_date (для удаления отсутствующих в файле)."""
        try:
            all_records = Applicant.query.all()
            existing_all = {(app.applicant_id, app.program_id) for app in all_records}
            keys_for_date = {(app.applicant_id, app.program_id) for app in all_records if app.upload_date == upload_date}
            return existing_all, keys_for_date
        except Exception as e:
            print(f"Ошибка при получении существующих записей: {e}")
            return set(), set()
    
    def _process_records(self, df, upload_date, existing_all, keys_for_this_date):
        """Одна запись на (applicant_id, программа): если уже есть в БД — обновляем (и дату на текущую); иначе создаём. Удаляем только тех, у кого дата D и кого нет в файле."""
        added = 0
        updated = 0
        errors = []
        processed_in_batch = 0
        file_keys = set()
        handled_in_run = set()
        
        for index, row in df.iterrows():
            try:
                applicant_id = int(row['ID'])
                program_code = str(row['Программа']).strip()
                program = self._find_program(program_code)
                if not program:
                    available = [p.code for p in Program.query.all()]
                    raise ValueError(f"Программа '{program_code}' не найдена. Доступные: {available}")
                
                key = (applicant_id, program.id)
                file_keys.add(key)
                
                if key in existing_all or key in handled_in_run:
                    success = self._update_applicant(row, applicant_id, program.id, upload_date)
                    if success:
                        updated += 1
                    handled_in_run.add(key)
                    existing_all.add(key)
                else:
                    success = self._create_applicant(row, upload_date, program)
                    if success:
                        added += 1
                        handled_in_run.add(key)
                        existing_all.add(key)
                
                processed_in_batch += 1
                if processed_in_batch >= BATCH_SIZE:
                    self.db.session.commit()
                    processed_in_batch = 0
                        
            except Exception as e:
                error_msg = f"Строка {index + 1} (ID {row.get('ID', 'N/A')}): {str(e)}"
                errors.append(error_msg)
                continue
        
        if processed_in_batch:
            self.db.session.commit()
        
       
        to_delete = keys_for_this_date - file_keys
        deleted_count = 0
        if to_delete:
            for applicant_id, program_id in to_delete:
                if self._delete_applicant_by_key(applicant_id, program_id, upload_date):
                    deleted_count += 1
            self.db.session.commit()
        
        return added, updated, deleted_count, errors
    
    def _create_applicant(self, row, upload_date, program=None):
        """Добавляет запись только если такой (applicant_id, program_id, upload_date) ещё нет — без дубликатов."""
        if program is None:
            program = self._find_program(str(row['Программа']).strip())
        if not program:
            raise ValueError(f"Программа не найдена")
        consent_value = row['Согласие']
        if isinstance(consent_value, str):
            consent = bool(self._parse_consent_value(consent_value))
        else:
            consent = bool(int(consent_value))
        applicant = Applicant(
            applicant_id=int(row['ID']),
            consent=consent,
            priority_1=int(row['Приоритет']),
            physics_score=int(row['Физика']),
            russian_score=int(row['Русский']),
            math_score=int(row['Математика']),
            achievements_score=int(row['Достижения']),
            total_score=int(row['Сумма']),
            program_id=program.id,
            upload_date=upload_date
        )
        self.db.session.add(applicant)
        return True
    
    def _find_program(self, program_code):
        program_code = str(program_code).strip()
        
        program = Program.query.filter_by(code=program_code).first()
        if program:
            return program
        
        clean_code = program_code.replace(' ', '')
        all_programs = Program.query.all()
        
        for p in all_programs:
            if p.code.replace(' ', '') == clean_code:
                return p
        
        for p in all_programs:
            if program_code in p.code or p.code in program_code:
                return p
        
        return None
    
    def _update_applicant(self, row, applicant_id, program_id, upload_date):
        """Обновляет единственную запись по (applicant_id, program_id) — без привязки к дате. Ставим новые данные и дату загрузки."""
        try:
            applicant = Applicant.query.filter_by(
                applicant_id=applicant_id,
                program_id=program_id
            ).first()
            
            if not applicant:
                return False
            
            consent_value = row['Согласие']
            if isinstance(consent_value, str):
                applicant.consent = bool(self._parse_consent_value(consent_value))
            else:
                applicant.consent = bool(int(consent_value))
            
            applicant.priority_1 = int(row['Приоритет'])
            applicant.physics_score = int(row['Физика'])
            applicant.russian_score = int(row['Русский'])
            applicant.math_score = int(row['Математика'])
            applicant.achievements_score = int(row['Достижения'])
            applicant.total_score = int(row['Сумма'])
            applicant.upload_date = upload_date
            
            return True
            
        except Exception as e:
            raise ValueError(f"Ошибка обновления абитуриента {applicant_id}: {str(e)}")
    
    def _delete_applicant_by_key(self, applicant_id, program_id, upload_date):
        """Удаляет только запись с данной датой загрузки (не трогает другие срезы)."""
        try:
            applicant = Applicant.query.filter_by(
                applicant_id=applicant_id,
                program_id=program_id,
                upload_date=upload_date
            ).first()
            
            if applicant:
                self.db.session.delete(applicant)
                print(f"    Удален абитуриент ID={applicant_id} (дата {upload_date})")
                return True
            
            return False
        except Exception as e:
            print(f"    Ошибка при удалении ID={applicant_id}: {e}")
            return False