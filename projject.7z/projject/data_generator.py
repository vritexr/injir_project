import pandas as pd
import numpy as np
from pathlib import Path
import random


output_dir = Path('абитуриенты')
output_dir.mkdir(exist_ok=True)


programs = ['ПМ', 'ИВТ', 'ИТСС', 'ИБ']


program_counts = {
    'ПМ': [60, 380, 1000, 1240],
    'ИВТ': [100, 370, 1150, 1390],
    'ИТСС': [50, 350, 1050, 1240],
    'ИБ': [70, 260, 800, 1190]
}


pair_intersections = {
    ('01.08', 'ПМ', 'ИВТ'): 22, ('01.08', 'ПМ', 'ИТСС'): 17, ('01.08', 'ПМ', 'ИБ'): 20,
    ('01.08', 'ИВТ', 'ИТСС'): 19, ('01.08', 'ИВТ', 'ИБ'): 22, ('01.08', 'ИТСС', 'ИБ'): 17,
    
    ('02.08', 'ПМ', 'ИВТ'): 190, ('02.08', 'ПМ', 'ИТСС'): 190, ('02.08', 'ПМ', 'ИБ'): 150,
    ('02.08', 'ИВТ', 'ИТСС'): 190, ('02.08', 'ИВТ', 'ИБ'): 140, ('02.08', 'ИТСС', 'ИБ'): 120,
    
    ('03.08', 'ПМ', 'ИВТ'): 760, ('03.08', 'ПМ', 'ИТСС'): 600, ('03.08', 'ПМ', 'ИБ'): 410,
    ('03.08', 'ИВТ', 'ИТСС'): 750, ('03.08', 'ИВТ', 'ИБ'): 460, ('03.08', 'ИТСС', 'ИБ'): 500,
    
    ('04.08', 'ПМ', 'ИВТ'): 1090, ('04.08', 'ПМ', 'ИТСС'): 1110, ('04.08', 'ПМ', 'ИБ'): 1070,
    ('04.08', 'ИВТ', 'ИТСС'): 1050, ('04.08', 'ИВТ', 'ИБ'): 1040, ('04.08', 'ИТСС', 'ИБ'): 1090
}


triple_intersections = {
    ('01.08', 'ПМ', 'ИВТ', 'ИТСС'): 5, ('01.08', 'ПМ', 'ИВТ', 'ИБ'): 5,
    ('01.08', 'ИВТ', 'ИТСС', 'ИБ'): 5, ('01.08', 'ПМ', 'ИТСС', 'ИБ'): 5,
    ('01.08', 'ПМ', 'ИВТ', 'ИТСС', 'ИБ'): 3,
    
    ('02.08', 'ПМ', 'ИВТ', 'ИТСС'): 70, ('02.08', 'ПМ', 'ИВТ', 'ИБ'): 70,
    ('02.08', 'ИВТ', 'ИТСС', 'ИБ'): 70, ('02.08', 'ПМ', 'ИТСС', 'ИБ'): 70,
    ('02.08', 'ПМ', 'ИВТ', 'ИТСС', 'ИБ'): 50,
    
    ('03.08', 'ПМ', 'ИВТ', 'ИТСС'): 500, ('03.08', 'ПМ', 'ИВТ', 'ИБ'): 260,
    ('03.08', 'ИВТ', 'ИТСС', 'ИБ'): 300, ('03.08', 'ПМ', 'ИТСС', 'ИБ'): 250,
    ('03.08', 'ПМ', 'ИВТ', 'ИТСС', 'ИБ'): 200,
    
    ('04.08', 'ПМ', 'ИВТ', 'ИТСС'): 1020, ('04.08', 'ПМ', 'ИВТ', 'ИБ'): 1020,
    ('04.08', 'ИВТ', 'ИТСС', 'ИБ'): 1000, ('04.08', 'ПМ', 'ИТСС', 'ИБ'): 1040,
    ('04.08', 'ПМ', 'ИВТ', 'ИТСС', 'ИБ'): 1000
}


dates = ['01.08', '02.08', '03.08', '04.08']


subjects = {
    'Физика': 100,
    'Русский': 100,
    'Математика': 100,
    'Достижения': 10
}

def generate_student_scores():
    """Генерирует баллы для абитуриента"""
    physics = random.randint(40, 100)
    russian = random.randint(40, 100)
    math = random.randint(40, 100)
    achievements = random.randint(0, 10)
    total = physics + russian + math + achievements
    
    return {
        'Физика': physics,
        'Русский': russian,
        'Математика': math,
        'Достижения': achievements,
        'Сумма': total
    }

def generate_consent():
    """Генерирует согласие (примерно 30% дают согласие)"""
    return 1 if random.random() < 0.3 else 0

def generate_priority():
    """Генерирует приоритет (1-4)"""
    return random.randint(1, 4)

def main():
    
    all_students = {}
    current_id = 1
    
    
    for date_idx, date in enumerate(dates):
        print(f"\n=== Генерация данных на {date} ===")
        
       
        program_sets = {program: set() for program in programs}
        
        
        print("Создание пересечений 3-х и 4-х программ...")
        
       
        triple_combinations = [
            (('ПМ', 'ИВТ', 'ИТСС'), triple_intersections[(date, 'ПМ', 'ИВТ', 'ИТСС')]),
            (('ПМ', 'ИВТ', 'ИБ'), triple_intersections[(date, 'ПМ', 'ИВТ', 'ИБ')]),
            (('ИВТ', 'ИТСС', 'ИБ'), triple_intersections[(date, 'ИВТ', 'ИТСС', 'ИБ')]),
            (('ПМ', 'ИТСС', 'ИБ'), triple_intersections[(date, 'ПМ', 'ИТСС', 'ИБ')])
        ]
        
        for programs_tuple, count in triple_combinations:
            for _ in range(count):
                scores = generate_student_scores()
                consent = generate_consent()
                
                
                for program in programs_tuple:
                    student_data = {
                        'ID': current_id,
                        'Согласие': consent,
                        'Приоритет': generate_priority(),
                        'Программа': program,
                        **scores
                    }
                    all_students[current_id] = student_data
                    program_sets[program].add(current_id)
                
                current_id += 1
        
        
        quadruple_count = triple_intersections[(date, 'ПМ', 'ИВТ', 'ИТСС', 'ИБ')]
        for _ in range(quadruple_count):
            scores = generate_student_scores()
            consent = generate_consent()
            
            for program in programs:
                student_data = {
                    'ID': current_id,
                    'Согласие': consent,
                    'Приоритет': generate_priority(),
                    'Программа': program,
                    **scores
                }
                all_students[current_id] = student_data
                program_sets[program].add(current_id)
            
            current_id += 1
        
       
        print("Создание пересечений 2-х программ...")
        pair_combinations = [
            (('ПМ', 'ИВТ'), pair_intersections[(date, 'ПМ', 'ИВТ')]),
            (('ПМ', 'ИТСС'), pair_intersections[(date, 'ПМ', 'ИТСС')]),
            (('ПМ', 'ИБ'), pair_intersections[(date, 'ПМ', 'ИБ')]),
            (('ИВТ', 'ИТСС'), pair_intersections[(date, 'ИВТ', 'ИТСС')]),
            (('ИВТ', 'ИБ'), pair_intersections[(date, 'ИВТ', 'ИБ')]),
            (('ИТСС', 'ИБ'), pair_intersections[(date, 'ИТСС', 'ИБ')])
        ]
        
        for (prog1, prog2), target_count in pair_combinations:
           
            existing_intersection = len(program_sets[prog1] & program_sets[prog2])
            needed = max(0, target_count - existing_intersection)
            
            for _ in range(needed):
                scores = generate_student_scores()
                consent = generate_consent()
                
                
                student_data1 = {
                    'ID': current_id,
                    'Согласие': consent,
                    'Приоритет': generate_priority(),
                    'Программа': prog1,
                    **scores
                }
                student_data2 = {
                    'ID': current_id + 1,
                    'Согласие': consent,
                    'Приоритет': generate_priority(),
                    'Программа': prog2,
                    **scores
                }
                
                all_students[current_id] = student_data1
                all_students[current_id + 1] = student_data2
                program_sets[prog1].add(current_id)
                program_sets[prog2].add(current_id + 1)
                
                current_id += 2
        
        
        print("Добавление уникальных абитуриентов...")
        for program in programs:
            current_count = len(program_sets[program])
            target_count = program_counts[program][date_idx]
            needed = max(0, target_count - current_count)
            
            for _ in range(needed):
                scores = generate_student_scores()
                consent = generate_consent()
                
                student_data = {
                    'ID': current_id,
                    'Согласие': consent,
                    'Приоритет': generate_priority(),
                    'Программа': program,
                    **scores
                }
                all_students[current_id] = student_data
                program_sets[program].add(current_id)
                current_id += 1
        
        
        date_students = list(all_students.values())
        date_students.sort(key=lambda x: (x['Программа'], x['ID']))
        df = pd.DataFrame(date_students)
        
       
        for program in programs:
            df_prog = df[df['Программа'] == program].copy()
            filename = f"{date}_{program}.xlsx"
            filepath = output_dir / filename
            df_prog.to_excel(filepath, index=False)
            print(f"  Сохранён {filename}: {len(df_prog)} записей")
        
        print(f"\nСтатистика по дате {date}:")
        for program in programs:
            program_count = len([s for s in date_students if s['Программа'] == program])
            print(f"  {program}: {program_count} абитуриентов")
        
        print(f"\nПроверка пересечений для {date}:")
        
        
        date_program_sets = {}
        for program in programs:
            date_program_sets[program] = {
                s['ID'] for s in date_students if s['Программа'] == program
            }
        
        
        print("  Парные пересечения:")
        for (d, prog1, prog2), expected in pair_intersections.items():
            if d == date:  
                actual = len(date_program_sets[prog1] & date_program_sets[prog2])
                print(f"    {prog1}-{prog2}: ожидалось {expected}, получено {actual}")
        
        
        print("  Тройные пересечения:")
        triple_check = [
            (('ПМ', 'ИВТ', 'ИТСС'), triple_intersections[(date, 'ПМ', 'ИВТ', 'ИТСС')]),
            (('ПМ', 'ИВТ', 'ИБ'), triple_intersections[(date, 'ПМ', 'ИВТ', 'ИБ')]),
            (('ИВТ', 'ИТСС', 'ИБ'), triple_intersections[(date, 'ИВТ', 'ИТСС', 'ИБ')]),
            (('ПМ', 'ИТСС', 'ИБ'), triple_intersections[(date, 'ПМ', 'ИТСС', 'ИБ')])
        ]
        
        for (prog1, prog2, prog3), expected in triple_check:
            actual = len(date_program_sets[prog1] & date_program_sets[prog2] & date_program_sets[prog3])
            print(f"    {prog1}-{prog2}-{prog3}: ожидалось {expected}, получено {actual}")
        
        print("  Четверное пересечение:")
        quadruple_expected = triple_intersections[(date, 'ПМ', 'ИВТ', 'ИТСС', 'ИБ')]
        quadruple_actual = len(date_program_sets['ПМ'] & date_program_sets['ИВТ'] & 
                              date_program_sets['ИТСС'] & date_program_sets['ИБ'])
        print(f"    ПМ-ИВТ-ИТСС-ИБ: ожидалось {quadruple_expected}, получено {quadruple_actual}")
        
        print(f"\nВсего уникальных абитуриентов (ID): {len(set(s['ID'] for s in date_students))}")
        print(f"Всего записей (с учетом дублирования по программам): {len(df)}")

if __name__ == "__main__":
    
    random.seed(42)
    np.random.seed(42)
    
    main()