from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Applicant(db.Model):
    """Модель абитуриента. Одна запись на (applicant_id, program_id); при повторной загрузке — обновление и смена даты."""
    __tablename__ = 'applicants'
    __table_args__ = (db.UniqueConstraint('applicant_id', 'program_id', name='uq_applicant_program'),)

    id = db.Column(db.Integer, primary_key=True)
    applicant_id = db.Column(db.Integer, nullable=False, index=True)  
    consent = db.Column(db.Boolean, default=False)
    priority_1 = db.Column(db.Integer)  
    priority_2 = db.Column(db.Integer)
    priority_3 = db.Column(db.Integer)
    priority_4 = db.Column(db.Integer)
    physics_score = db.Column(db.Integer)
    russian_score = db.Column(db.Integer)
    math_score = db.Column(db.Integer)
    achievements_score = db.Column(db.Integer)
    total_score = db.Column(db.Integer)
    
    
    program_id = db.Column(db.Integer, db.ForeignKey('programs.id'))
    program = db.relationship('Program', back_populates='applicants')
    
    
    upload_date = db.Column(db.Date, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<Applicant {self.applicant_id} - {self.total_score} pts>'

class Program(db.Model):
    """Модель образовательной программы"""
    __tablename__ = 'programs'
    
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(10), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    full_name = db.Column(db.String(200))
    budget_places = db.Column(db.Integer, default=0)
    
   
    applicants = db.relationship('Applicant', back_populates='program')
    passing_scores = db.relationship('PassingScore', back_populates='program')
    
    def __repr__(self):
        return f'<Program {self.code}: {self.name}>'

class PassingScore(db.Model):
    """Модель проходного балла по дням"""
    __tablename__ = 'passing_scores'
    
    id = db.Column(db.Integer, primary_key=True)
    program_id = db.Column(db.Integer, db.ForeignKey('programs.id'), nullable=False)
    program = db.relationship('Program', back_populates='passing_scores')
    
    score = db.Column(db.Integer)
    date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(20), default='CALCULATED')  
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<PassingScore {self.program.code} - {self.date}: {self.score}>'

class AdmissionReport(db.Model):
    """Модель отчетов"""
    __tablename__ = 'admission_reports'
    
    id = db.Column(db.Integer, primary_key=True)
    report_date = db.Column(db.Date, nullable=False)
    generated_at = db.Column(db.DateTime, default=datetime.utcnow)
    file_path = db.Column(db.String(500))
    summary_data = db.Column(db.JSON)  
    
    def __repr__(self):
        return f'<AdmissionReport {self.report_date}>'