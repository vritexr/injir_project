"""
Расчёт проходных баллов и списков зачисленных по правилам приёма:
- Учитываются только абитуриенты, подавшие согласие на зачисление (consent=True).
- По каждой ОП рассматриваются только те, кто подал заявку на эту программу (program_id).
- Ранжирование по убыванию суммы баллов; проходной балл = балл последнего из N зачисленных,
  где N = количество бюджетных мест. При недоборе — статус НЕДОБОР.
"""
from models import Applicant, Program, PassingScore, db
from datetime import datetime
from typing import List, Dict


def calculate_passing_scores(date: datetime.date):
    """Проходной балл по ОП = балл последнего зачисленного при заполнении всех мест (только с согласием)."""
    programs = Program.query.all()

    for program in programs:
        applicants = Applicant.query.filter_by(
            program_id=program.id,
            upload_date=date,
            consent=True,
        ).order_by(Applicant.total_score.desc()).all()

        if len(applicants) < program.budget_places:
            score_record = PassingScore(
                program_id=program.id,
                date=date,
                score=None,
                status='NOT_ENOUGH'
            )
        else:
            passing_score = applicants[program.budget_places - 1].total_score
            
            score_record = PassingScore(
                program_id=program.id,
                date=date,
                score=passing_score,
                status='CALCULATED'
            )
        
        existing = PassingScore.query.filter_by(
            program_id=program.id,
            date=date
        ).first()
        
        if existing:
            existing.score = score_record.score
            existing.status = score_record.status
        else:
            db.session.add(score_record)
    
    db.session.commit()
    
    return True

def get_admitted_applicants(date: datetime.date) -> Dict[str, List]:
    programs = Program.query.all()
    result = {}
    
    for program in programs:
        passing_score = PassingScore.query.filter_by(
            program_id=program.id,
            date=date
        ).first()
        
        if not passing_score or passing_score.status == 'NOT_ENOUGH':
            result[program.code] = []
            continue
        
        admitted = Applicant.query.filter_by(
            program_id=program.id,
            upload_date=date,
            consent=True
        ).filter(Applicant.total_score >= passing_score.score)\
         .order_by(Applicant.total_score.desc())\
         .limit(program.budget_places)\
         .all()
        
        result[program.code] = [
            {'id': app.applicant_id, 'score': app.total_score}
            for app in admitted
        ]
    
    return result

def get_statistics(date: datetime.date) -> Dict:
    programs = Program.query.all()
    stats = {}
    
    for program in programs:
        total_applications = Applicant.query.filter_by(
            program_id=program.id,
            upload_date=date
        ).count()
        
        priorities = {}
        for i in range(1, 5):
            count = Applicant.query.filter_by(
                program_id=program.id,
                upload_date=date,
                priority_1=i
            ).count()
            priorities[f'priority_{i}'] = count
        
        admitted = get_admitted_applicants(date).get(program.code, [])
        admitted_ids = [app['id'] for app in admitted]

        admitted_by_priority = {f'admitted_{i}': 0 for i in range(1, 5)}
        if admitted_ids:
            
            admitted_apps = Applicant.query.filter(
                Applicant.applicant_id.in_(admitted_ids),
                Applicant.program_id == program.id,
            ).all()

            for app in admitted_apps:
                priority = app.priority_1
                if priority in [1, 2, 3, 4]:
                    admitted_by_priority[f'admitted_{priority}'] += 1
        
        stats[program.code] = {
            'total_applications': total_applications,
            'budget_places': program.budget_places,
            'priorities': priorities,
            'admitted_by_priority': admitted_by_priority,
            'total_admitted': len(admitted)
        }
    
    return stats