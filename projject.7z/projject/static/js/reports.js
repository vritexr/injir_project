
(function () {
  'use strict';

  function previewReport() {
    const dateInput = document.getElementById('report_date');
    const date = dateInput ? dateInput.value : '';
    if (!date) {
      alert('Пожалуйста, выберите дату для отчета');
      return;
    }
    alert(
      'Функция предварительного просмотра в разработке. Для просмотра сформируйте отчет.'
    );
  }

  document.addEventListener('DOMContentLoaded', function () {
    const btn = document.querySelector('[onclick="previewReport()"]');
    if (btn) {
      btn.removeAttribute('onclick');
      btn.addEventListener('click', previewReport);
    }
  });

  window.previewReport = previewReport;
})();
