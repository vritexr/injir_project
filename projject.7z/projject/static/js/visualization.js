

let passingScoresChart = null;
let applicantsDistributionChart = null;
let allChartData = {};
let programsList = [];


const programColors = {
    'ПМ': '#FF6384',    
    'ИВТ': '#36A2EB',   
    'ИТСС': '#FFCE56',  
    'ИБ': '#4BC0C0'     
};

function initializeVisualization() {
    console.log('Инициализация визуализации...');
    
    
    allChartData = window.chartData || {};
    programsList = window.programsData || [];
    const distributionStats = window.distributionStats || {};
    
    console.log('Данные графиков:', allChartData);
    console.log('Список программ:', programsList);
    
    
    if (Object.keys(allChartData).length === 0) {
        showAlert('Нет данных о проходных баллах. Сначала загрузите данные через раздел "Загрузка данных".', 'warning');
    }
    
    
    initializeProgramColors();
    
    
    createPassingScoresChart();
    createApplicantsDistributionChart();
    
   
    loadStatistics(distributionStats);
    
    
    loadHeatmapData();
    
    
    updateDataInfo();
}


function initializeProgramColors() {
    for (const [programCode, color] of Object.entries(programColors)) {
        document.documentElement.style.setProperty(`--program-color-${programCode}`, color);
    }
}


function createPassingScoresChart() {
    const canvas = document.getElementById('passingScoresChart');
    if (!canvas) {
        console.error('Canvas element not found');
        return;
    }
    
    const ctx = canvas.getContext('2d');
    
    
    const datasets = prepareChartDatasets();
    
    
    const firstProgramWithData = Object.values(allChartData).find(program => program.dates && program.dates.length > 0);
    const labels = firstProgramWithData ? firstProgramWithData.dates : [];
    
    passingScoresChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: datasets
        },
        options: getChartOptions()
    });
}


function prepareChartDatasets() {
    const datasets = [];
    const showZeroValues = document.getElementById('showZeroValues')?.checked || true;
    
    for (const [programCode, programData] of Object.entries(allChartData)) {
        if (!programData || !programData.scores) continue;
        
        
        let filteredScores, filteredDates;
        
        if (showZeroValues) {
            filteredScores = programData.scores;
            filteredDates = programData.dates || [];
        } else {
            filteredScores = programData.scores.filter(score => score > 0);
            filteredDates = (programData.dates || []).filter((date, index) => programData.scores[index] > 0);
        }
        
        if (filteredScores.length > 0) {
            const smoothLines = document.getElementById('smoothLines')?.checked || true;
            
            datasets.push({
                label: programCode,
                data: filteredScores,
                borderColor: programColors[programCode] || '#999999',
                backgroundColor: (programColors[programCode] || '#999999') + '20',
                fill: false,
                tension: smoothLines ? 0.1 : 0,
                pointRadius: 6,
                pointHoverRadius: 8,
                pointBackgroundColor: programColors[programCode] || '#999999',
                borderWidth: 2,
                hidden: false
            });
        }
    }
    
    return datasets;
}


function getChartOptions() {
    return {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            title: {
                display: true,
                text: 'Динамика проходных баллов',
                font: {
                    size: 16
                }
            },
            legend: {
                display: true,
                position: 'top',
                labels: {
                    usePointStyle: true,
                    pointStyle: 'circle'
                }
            },
            tooltip: {
                callbacks: {
                    label: function(context) {
                        const value = context.raw;
                        const program = context.dataset.label;
                        const status = allChartData[program]?.statuses?.[context.dataIndex];
                        
                        if (status === 'NOT_ENOUGH') {
                            return `${program}: НЕДОБОР`;
                        }
                        return `${program}: ${value} баллов`;
                    }
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: 'Проходной балл'
                },
                suggestedMin: 200,
                suggestedMax: 300
            },
            x: {
                title: {
                    display: true,
                    text: 'Дата'
                },
                ticks: {
                    maxRotation: 45
                }
            }
        },
        interaction: {
            intersect: false,
            mode: 'index'
        },
        animation: {
            duration: 1000
        }
    };
}


function createApplicantsDistributionChart() {
    const canvas = document.getElementById('applicantsDistributionChart');
    if (!canvas) {
        console.error('Canvas element for distribution chart not found');
        return;
    }
    
    const ctx = canvas.getContext('2d');
    
    applicantsDistributionChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [],
                borderWidth: 2,
                hoverOffset: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            aspectRatio: 1.5,
            plugins: {
                legend: {
                    position: 'right',
                },
                title: {
                    display: true,
                    text: 'Распределение абитуриентов по программам'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label;
                            const value = context.raw;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = total > 0 ? Math.round((value / total) * 100) : 0;
                            return `${label}: ${value} заявлений (${percentage}%)`;
                        }
                    }
                }
            },
            onClick: handlePieChartClick
        }
    });
}


function handlePieChartClick(event, elements) {
    if (elements && elements.length > 0) {
        const index = elements[0].index;
        const programCode = applicantsDistributionChart.data.labels[index];
        showProgramDetails(programCode);
    }
}


function showProgramDetails(programCode) {
    const detailContent = document.getElementById('programDetailContent');
    if (!detailContent) return;
    
    const program = programsList.find(p => p.code === programCode);
    if (!program) return;
    
    
    const programStats = window.distributionStats?.[programCode] || {};
    
    
    let lastScore = 'НЕТ ДАННЫХ';
    let scoreStatus = 'bg-warning';
    
    if (allChartData && allChartData[programCode] && allChartData[programCode].scores) {
        const scores = allChartData[programCode].scores;
        const statuses = allChartData[programCode].statuses || [];
        
        
        for (let i = scores.length - 1; i >= 0; i--) {
            if (scores[i] > 0) {
                lastScore = scores[i] + ' баллов';
                scoreStatus = 'bg-success';
                break;
            } else if (statuses[i] === 'NOT_ENOUGH') {
                lastScore = 'НЕДОБОР';
                scoreStatus = 'bg-warning';
                break;
            }
        }
    }
    
 
    const totalApps = programStats.total_applications || 0;
    const ratio = program.budget_places > 0 
        ? (totalApps / program.budget_places).toFixed(1) 
        : 0;
    
    detailContent.innerHTML = `
        <div class="card">
            <div class="card-header" style="background-color: ${programColors[programCode] || '#6c757d'}; color: white;">
                <h5 class="mb-0">${program.name} (${programCode})</h5>
            </div>
            <div class="card-body">
                <table class="table table-sm">
                    <tr>
                        <td><strong>Бюджетных мест:</strong></td>
                        <td class="text-end">${program.budget_places || 0}</td>
                    </tr>
                    <tr>
                        <td><strong>Всего заявлений:</strong></td>
                        <td class="text-end">${totalApps}</td>
                    </tr>
                    <tr>
                        <td><strong>С согласием:</strong></td>
                        <td class="text-end">${programStats.with_consent || 0}</td>
                    </tr>
                    <tr>
                        <td><strong>Соотношение:</strong></td>
                        <td class="text-end">${ratio} чел/место</td>
                    </tr>
                    <tr>
                        <td><strong>Последний проходной:</strong></td>
                        <td class="text-end">
                            <span class="badge ${scoreStatus}">${lastScore}</span>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    `;
}


function loadStatistics(stats = {}) {
    updateProgramCards(stats);
    updateDistributionChart(stats);
}


function updateProgramCards(stats) {
    programsList.forEach(program => {
        const programStats = stats[program.code] || {};
        
        const applicantsElement = document.getElementById(`program-applicants-${program.code}`);
        const consentsElement = document.getElementById(`program-consents-${program.code}`);
        
        if (applicantsElement) {
            applicantsElement.textContent = programStats.total_applications || 0;
        }
        
        if (consentsElement) {
            consentsElement.textContent = programStats.with_consent || 0;
        }
        
       
        const card = document.querySelector(`.program-stat-card[data-program="${program.code}"]`);
        if (card) {
            card.classList.add('updated');
            setTimeout(() => card.classList.remove('updated'), 1000);
        }
    });
}

function updateDistributionChart(stats) {
    if (!applicantsDistributionChart) return;
    
    const labels = [];
    const data = [];
    const backgroundColors = [];
    
    if (Object.keys(stats).length > 0) {
        const sortedPrograms = Object.entries(stats)
            .sort((a, b) => (b[1].total_applications || 0) - (a[1].total_applications || 0));
        
        sortedPrograms.forEach(([programCode, programStats]) => {
            labels.push(programCode);
            data.push(programStats.total_applications || 0);
            backgroundColors.push(programColors[programCode] || '#CCCCCC');
        });
    } else {
        programsList.forEach(program => {
            labels.push(program.code);
            data.push(0);
            backgroundColors.push(programColors[program.code] || '#CCCCCC');
        });
    }
    
    applicantsDistributionChart.data.labels = labels;
    applicantsDistributionChart.data.datasets[0].data = data;
    applicantsDistributionChart.data.datasets[0].backgroundColor = backgroundColors;
    applicantsDistributionChart.update();
}

function loadHeatmapData() {
    const heatmapBody = document.getElementById('heatmapBody');
    if (!heatmapBody) return;
    
    if (Object.keys(allChartData).length === 0) {
        heatmapBody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center text-muted py-3">
                    <i class="bi bi-exclamation-circle"></i> Нет данных для отображения
                </td>
            </tr>
        `;
        return;
    }
    

    const allDates = new Set();
    Object.values(allChartData).forEach(program => {
        if (program && program.dates) {
            program.dates.forEach(date => allDates.add(date));
        }
    });
    
    const sortedDates = Array.from(allDates).sort();
    

    if (sortedDates.length === 0) {
        heatmapBody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center text-muted py-3">
                    <i class="bi bi-info-circle"></i> Нет данных для тепловой карты
                </td>
            </tr>
        `;
        return;
    }
    

    let html = '';
    
    sortedDates.forEach(date => {
        html += `<tr><td><strong>${date}</strong></td>`;
        
        programsList.forEach(program => {
            const programData = allChartData[program.code];
            if (programData && programData.dates) {
                const dateIndex = programData.dates.indexOf(date);
                const score = dateIndex !== -1 ? programData.scores[dateIndex] : null;
                const status = dateIndex !== -1 ? programData.statuses?.[dateIndex] : null;
                
                html += `<td class="text-center">`;
                
                if (score !== null && score !== undefined) {
                  
                    let badgeClass = 'bg-secondary';
                    if (status === 'NOT_ENOUGH') {
                        badgeClass = 'bg-warning';
                        html += `<span class="badge ${badgeClass}">НЕДОБОР</span>`;
                    } else if (score > 280) {
                        badgeClass = 'bg-danger';
                        html += `<span class="badge ${badgeClass}">${score}</span>`;
                    } else if (score > 250) {
                        badgeClass = 'bg-warning text-dark';
                        html += `<span class="badge ${badgeClass}">${score}</span>`;
                    } else if (score > 0) {
                        badgeClass = 'bg-success';
                        html += `<span class="badge ${badgeClass}">${score}</span>`;
                    } else {
                        html += `<span class="text-muted">-</span>`;
                    }
                } else {
                    html += `<span class="text-muted">-</span>`;
                }
                
                html += `</td>`;
            } else {
                html += `<td class="text-center"><span class="text-muted">-</span></td>`;
            }
        });
        
        html += `</tr>`;
    });
    
    heatmapBody.innerHTML = html;
}


function updateDataInfo() {
    
    const activePrograms = Object.values(allChartData).filter(program => 
        program && program.scores && program.scores.some(score => score > 0)
    ).length;
    
    
    let maxDays = 0;
    Object.values(allChartData).forEach(program => {
        if (program && program.scores) {
            const daysWithData = program.scores.filter(score => score > 0).length;
            maxDays = Math.max(maxDays, daysWithData);
        }
    });
    
   
    const activeProgramsElement = document.getElementById('activeProgramsCount');
    const daysCountElement = document.getElementById('daysCount');
    const lastUpdateElement = document.getElementById('lastUpdate');
    
    if (activeProgramsElement) {
        activeProgramsElement.textContent = activePrograms;
    }
    if (daysCountElement) {
        daysCountElement.textContent = maxDays;
    }
    if (lastUpdateElement) {
        lastUpdateElement.textContent = new Date().toLocaleTimeString();
    }
}


function updateCharts() {
    if (passingScoresChart) {
        passingScoresChart.data.datasets = prepareChartDatasets();
        passingScoresChart.update();
    }
    
    updateDataInfo();
}


function toggleProgram(programCode) {
    if (!passingScoresChart) return;
    
    const datasetIndex = passingScoresChart.data.datasets.findIndex(ds => ds.label === programCode);
    if (datasetIndex !== -1) {
        const meta = passingScoresChart.getDatasetMeta(datasetIndex);
        meta.hidden = !meta.hidden;
        passingScoresChart.update();
        
        
        const activePrograms = passingScoresChart.data.datasets.filter(
            (ds, idx) => !passingScoresChart.getDatasetMeta(idx).hidden
        ).length;
        
        const activeProgramsElement = document.getElementById('activeProgramsCount');
        if (activeProgramsElement) {
            activeProgramsElement.textContent = activePrograms;
        }
    }
}


function toggleDataPoints() {
    if (!passingScoresChart) return;
    
    const showPoints = passingScoresChart.data.datasets[0].pointRadius === 0;
    const newRadius = showPoints ? 6 : 0;
    const newHoverRadius = showPoints ? 8 : 0;
    
    passingScoresChart.data.datasets.forEach(dataset => {
        dataset.pointRadius = newRadius;
        dataset.pointHoverRadius = newHoverRadius;
    });
    
    passingScoresChart.update();
}


function refreshChartData() {
    showAlert('Обновление данных...', 'info');
    

    fetch('/api/visualization-data')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            window.chartData = data;
            allChartData = data;
            
        
            if (passingScoresChart) {
                passingScoresChart.destroy();
            }
            createPassingScoresChart();
            
          
            loadStatistics();
            loadHeatmapData();
            updateDataInfo();
            
            showAlert('Данные успешно обновлены', 'success');
        })
        .catch(error => {
            console.error('Ошибка обновления данных:', error);
            showAlert('Ошибка обновления данных. Проверьте подключение.', 'danger');
        });
}


function showAlert(message, type = 'info') {
    const alertDiv = document.getElementById('dataAlert');
    const messageSpan = document.getElementById('alertMessage');
    
    if (!alertDiv || !messageSpan) return;
    
    
    alertDiv.className = `alert alert-${type}`;
    messageSpan.textContent = message;
    
    
    alertDiv.style.display = 'block';
    
    
    setTimeout(() => {
        alertDiv.style.display = 'none';
    }, 5000);
}


function exportChart() {
    if (passingScoresChart) {
        const link = document.createElement('a');
        link.download = `график-проходных-баллов-${new Date().toISOString().split('T')[0]}.png`;
        link.href = passingScoresChart.toBase64Image();
        link.click();
    }
}


 
function loadPassingScoresByDate() {
    const sel = document.getElementById('passingScoreDateSelect');
    const date = sel ? sel.value : '';
    const body = document.getElementById('passingScoreBody');
    const timeEl = document.getElementById('passingScoreActualTime');
    const badgeEl = document.getElementById('passingScoreTimeBadge');
    if (!date) {
        if (body) body.innerHTML = '<tr><td colspan="3" class="text-center text-muted">Нет данных</td></tr>';
        if (timeEl) timeEl.textContent = '—';
        if (badgeEl) badgeEl.textContent = '—';
        return;
    }
    if (body) body.innerHTML = '<tr><td colspan="3" class="text-center"><div class="spinner-border spinner-border-sm"></div> Загрузка...</td></tr>';
    fetch('/api/passing_scores_by_date?date=' + encodeURIComponent(date))
        .then(function (r) { return r.json(); })
        .then(function (data) {
            if (timeEl) timeEl.textContent = (data.date_display || data.date || '') + ' ' + (data.time || '');
            if (badgeEl) badgeEl.textContent = data.time || '—';
            const progs = data.programs || [];
            if (progs.length === 0) {
                body.innerHTML = '<tr><td colspan="3" class="text-center text-muted">Нет данных по выбранной дате</td></tr>';
                return;
            }
            let html = '';
            progs.forEach(function (p) {
                const score = (p.status === 'NOT_ENOUGH' || p.passing_score == null) ? 'НЕДОБОР' : String(p.passing_score);
                html += '<tr><td>' + (p.name || p.code) + '</td><td>' + (p.budget_places || '—') + '</td><td>' + score + '</td></tr>';
            });
            body.innerHTML = html;
        })
        .catch(function () {
            if (body) body.innerHTML = '<tr><td colspan="3" class="text-center text-danger">Ошибка загрузки</td></tr>';
        });
}


function initVisualizationPage() {
    try {
        allChartData = window.chartData || {};
        programsList = window.programsData || [];
        if (typeof initializeVisualization === 'function') {
            initializeVisualization();
        }
        loadPassingScoresByDate();
        const passingDateSel = document.getElementById('passingScoreDateSelect');
        if (passingDateSel) passingDateSel.addEventListener('change', loadPassingScoresByDate);
        const showZeroCheckbox = document.getElementById('showZeroValues');
        const smoothLinesCheckbox = document.getElementById('smoothLines');
        if (showZeroCheckbox) {
            showZeroCheckbox.addEventListener('change', function () {
                if (typeof updateCharts === 'function') updateCharts();
            });
        }
        if (smoothLinesCheckbox) {
            smoothLinesCheckbox.addEventListener('change', function () {
                if (typeof updateCharts === 'function') updateCharts();
            });
        }
    } catch (error) {
        console.error('Ошибка инициализации:', error);
        if (typeof showAlert === 'function') showAlert('Ошибка загрузки данных. Пожалуйста, обновите страницу.', 'danger');
    }
}