
(function () {
  'use strict';

  const currentYear = new Date().getFullYear();

  function initQuickDateButtons() {
    document.querySelectorAll('[data-date]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        const parts = this.getAttribute('data-date').split('-');
        const dateStr = currentYear + '-' + parts[0] + '-' + parts[1];
        const input = document.getElementById('upload_date');
        if (input) input.value = dateStr;
      });
    });
  }

  function generateExampleCSV() {
    const csvContent =
      'ID,Согласие,Приоритет,Программа,Физика,Русский,Математика,Достижения,Сумма\n' +
      '1001,1,1,ПМ,85,90,95,5,275\n' +
      '1002,0,2,ИВТ,78,88,92,3,261\n' +
      '1003,1,1,ИТСС,82,85,88,7,262\n' +
      '1004,1,3,ИБ,75,80,85,2,242\n' +
      '1005,0,1,ПМ,90,85,88,8,271';

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'пример_конкурсного_списка.csv';
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
    alert('Пример CSV файла скачан!');
  }

  function generateExampleExcel() {
    alert(
      'Для генерации Excel файла требуется серверная обработка. Используйте CSV или создайте Excel вручную.'
    );
  }

  document.addEventListener('DOMContentLoaded', function () {
    initQuickDateButtons();
    var form = document.querySelector('form[action*="upload"]');
    if (form) {
      form.addEventListener('submit', function (e) {
        var input = document.getElementById('files');
        if (input && (!input.files || input.files.length === 0)) {
          e.preventDefault();
          alert('Выберите хотя бы один файл.');
          return false;
        }
      });
    }
  });

  window.generateExampleCSV = generateExampleCSV;
  window.generateExampleExcel = generateExampleExcel;
})();
