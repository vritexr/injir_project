
(function () {
  'use strict';

  let currentSortBy = 'total_score';
  let currentOrder = 'desc';
  let currentPage = 1;
  const perPage = 25;

  function getEl(id) {
    return document.getElementById(id);
  }

  function applyFiltersAndReload() {
    currentPage = 1;
    const searchInput = getEl('searchById');
    if (searchInput) searchInput.value = '';
    loadApplicants();
  }

  function searchByApplicantId() {
    const searchInput = getEl('searchById');
    const id = searchInput ? searchInput.value.trim() : '';
    if (!id) {
      loadApplicants();
      return;
    }
    currentPage = 1;
    loadApplicants();
  }

  function goToPage(page) {
    currentPage = page;
    loadApplicants();
  }

  function loadApplicants() {
    const program = (getEl('programFilter') && getEl('programFilter').value) || 'all';
    const date = (getEl('dateFilter') && getEl('dateFilter').value) || 'all';
    const consent = (getEl('consentFilter') && getEl('consentFilter').value) || 'all';
    const applicantId = getEl('searchById') ? getEl('searchById').value.trim() : '';
    const tbody = getEl('applicantsBody');

    if (!tbody) return;

    tbody.innerHTML =
      '<tr><td colspan="9" class="text-center">' +
      '<div class="spinner-border text-primary" role="status"></div>' +
      '<p class="mt-2">Загрузка данных...</p></td></tr>';

    let url =
      '/api/applicants?page=' +
      currentPage +
      '&per_page=' +
      perPage +
      '&';
    if (program !== 'all') url += 'program=' + encodeURIComponent(program) + '&';
    if (date !== 'all') url += 'date=' + encodeURIComponent(date) + '&';
    if (consent !== 'all') url += 'consent=' + encodeURIComponent(consent) + '&';
    if (applicantId) url += 'applicant_id=' + encodeURIComponent(applicantId) + '&';
    url += 'sort=' + encodeURIComponent(currentSortBy) + '&order=' + encodeURIComponent(currentOrder);

    fetch(url)
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        const items = data.items || [];
        const total = data.total !== undefined ? data.total : items.length;
        const page = data.page || 1;
        const pages = data.pages || 1;
        updateApplicantsTable(items);
        const totalEl = getEl('applicantTotal');
        if (totalEl) totalEl.textContent = total;
        renderPagination(page, pages, total);
      })
      .catch(function (err) {
        console.error('Ошибка:', err);
        tbody.innerHTML =
          '<tr><td colspan="9" class="text-center text-danger">' +
          '<i class="bi bi-exclamation-triangle"></i> Ошибка загрузки данных</td></tr>';
        const totalEl = getEl('applicantTotal');
        if (totalEl) totalEl.textContent = '0';
        const nav = getEl('paginationNav');
        if (nav) nav.style.display = 'none';
      });
  }

  function renderPagination(page, pages, total) {
    const nav = getEl('paginationNav');
    const list = getEl('paginationList');
    if (!nav || !list) return;
    if (pages <= 1 || total === 0) {
      nav.style.display = 'none';
      return;
    }
    nav.style.display = 'block';
    let html = '';
    html +=
      '<li class="page-item' +
      (page <= 1 ? ' disabled' : '') +
      '"><a class="page-link" href="#" data-page="' +
      (page - 1) +
      '">Назад</a></li>';
    const start = Math.max(1, page - 2);
    const end = Math.min(pages, page + 2);
    if (start > 1) {
      html += '<li class="page-item"><a class="page-link" href="#" data-page="1">1</a></li>';
      if (start > 2) html += '<li class="page-item disabled"><span class="page-link">…</span></li>';
    }
    for (let i = start; i <= end; i++) {
      html +=
        '<li class="page-item' +
        (i === page ? ' active' : '') +
        '"><a class="page-link" href="#" data-page="' +
        i +
        '">' +
        i +
        '</a></li>';
    }
    if (end < pages) {
      if (end < pages - 1) html += '<li class="page-item disabled"><span class="page-link">…</span></li>';
      html +=
        '<li class="page-item"><a class="page-link" href="#" data-page="' +
        pages +
        '">' +
        pages +
        '</a></li>';
    }
    html +=
      '<li class="page-item' +
      (page >= pages ? ' disabled' : '') +
      '"><a class="page-link" href="#" data-page="' +
      (page + 1) +
      '">Вперёд</a></li>';
    list.innerHTML = html;
    list.querySelectorAll('a[data-page]').forEach(function (a) {
      a.addEventListener('click', function (e) {
        e.preventDefault();
        const p = parseInt(this.getAttribute('data-page'), 10);
        if (!isNaN(p) && p >= 1) goToPage(p);
      });
    });
  }

  function updateApplicantsTable(data) {
    const tbody = getEl('applicantsBody');
    const countEl = getEl('applicantCount');
    if (!tbody) return;
    if (!data || data.length === 0) {
      tbody.innerHTML =
        '<tr><td colspan="9" class="text-center text-muted">' +
        '<i class="bi bi-info-circle"></i> Нет данных для отображения</td></tr>';
      if (countEl) countEl.textContent = '0';
      return;
    }
    let html = '';
    data.forEach(function (applicant) {
      const consentBadge =
        applicant.consent === 'Да'
          ? '<span class="badge bg-success"><i class="bi bi-check-circle"></i> Да</span>'
          : '<span class="badge bg-secondary"><i class="bi bi-x-circle"></i> Нет</span>';
      html +=
        '<tr><td>' +
        applicant.id +
        '</td><td><span class="badge bg-primary">' +
        applicant.program +
        '</span></td><td>' +
        applicant.priority +
        '</td><td>' +
        applicant.physics +
        '</td><td>' +
        applicant.russian +
        '</td><td>' +
        applicant.math +
        '</td><td>' +
        applicant.achievements +
        '</td><td><strong>' +
        applicant.total +
        '</strong></td><td>' +
        consentBadge +
        '</td></tr>';
    });
    tbody.innerHTML = html;
    if (countEl) countEl.textContent = data.length;
  }

  function sortTable(column, order) {
    currentSortBy = column;
    currentOrder = order;
    currentPage = 1;
    loadApplicants();
  }

  function resetFilters() {
    const programEl = getEl('programFilter');
    const dateEl = getEl('dateFilter');
    const consentEl = getEl('consentFilter');
    const searchEl = getEl('searchById');
    if (programEl) programEl.value = 'all';
    if (dateEl) dateEl.value = 'all';
    if (consentEl) consentEl.value = 'all';
    if (searchEl) searchEl.value = '';
    currentPage = 1;
    loadApplicants();
  }

  function showConfirmModal(title, message, confirmCallback) {
    const titleEl = getEl('confirmModalTitle');
    const bodyEl = getEl('confirmModalBody');
    const btnEl = getEl('confirmModalButton');
    const modalEl = getEl('confirmModal');
    if (!titleEl || !bodyEl || !btnEl || !modalEl) return;
    titleEl.textContent = title;
    bodyEl.textContent = message;
    btnEl.onclick = function () {
      confirmCallback();
      const modal = bootstrap.Modal.getInstance(modalEl);
      if (modal) modal.hide();
    };
    const modal = new bootstrap.Modal(modalEl);
    modal.show();
  }

  function deleteDataByDate() {
    const dateEl = getEl('deleteDate');
    const date = dateEl ? dateEl.value : '';
    if (!date) {
      alert('Пожалуйста, выберите дату');
      return;
    }
    showConfirmModal(
      'Удаление данных',
      'Вы уверены, что хотите удалить все данные за ' + date + '? Это действие необратимо.',
      function () {
        fetch('/manage-data', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'action=delete_applicants&date=' + encodeURIComponent(date),
        })
          .then(function () {
            alert('Данные успешно удалены');
            location.reload();
          })
          .catch(function (err) {
            console.error(err);
            alert('Ошибка при удалении данных: ' + (err && err.message ? err.message : ''));
          });
      }
    );
  }

  function deleteAllData() {
    showConfirmModal(
      'Полное удаление данных',
      'Вы уверены, что хотите удалить ВСЕ данные (абитуриентов и проходные баллы)? Это действие необратимо. Программы останутся нетронутыми.',
      function () {
        fetch('/manage-data', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'action=delete_all&confirm=yes',
        })
          .then(function () {
            alert('Все данные успешно удалены');
            location.reload();
          })
          .catch(function (err) {
            console.error(err);
            alert('Ошибка при удалении данных: ' + (err && err.message ? err.message : ''));
          });
      }
    );
  }

  function resetPrograms() {
    showConfirmModal(
      'Сброс программ',
      'Вы уверены, что хотите сбросить программы к исходным значениям? Текущие настройки программ будут потеряны.',
      function () {
        fetch('/manage-data', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'action=reset_programs',
        })
          .then(function () {
            alert('Программы успешно сброшены к исходным значениям');
            location.reload();
          })
          .catch(function (err) {
            console.error(err);
            alert('Ошибка при сбросе программ: ' + (err && err.message ? err.message : ''));
          });
      }
    );
  }

  document.addEventListener('DOMContentLoaded', function () {
    loadApplicants();
    const confirmCheck = getEl('confirmDeleteAll');
    const deleteAllBtn = getEl('deleteAllBtn');
    if (confirmCheck && deleteAllBtn) {
      confirmCheck.addEventListener('change', function () {
        deleteAllBtn.disabled = !this.checked;
      });
    }
    const searchById = getEl('searchById');
    if (searchById) {
      searchById.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          searchByApplicantId();
        }
      });
    }
  });

  window.applyFiltersAndReload = applyFiltersAndReload;
  window.searchByApplicantId = searchByApplicantId;
  window.goToPage = goToPage;
  window.sortTable = sortTable;
  window.resetFilters = resetFilters;
  window.deleteDataByDate = deleteDataByDate;
  window.deleteAllData = deleteAllData;
  window.resetPrograms = resetPrograms;
})();
