import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app import app
from models import db, Program

with app.app_context():
    print("Проверка подключения к БД...")
    
    try:
        count = db.session.query(Program).count()
        print(f"Подключение к БД успешно")
        print(f"В БД найдено {count} программ")
        
        if count > 0:
            programs = Program.query.all()
            print("\nСписок программ:")
            for p in programs:
                print(f"  Код: '{p.code}', Название: {p.name}, Мест: {p.budget_places}")
        else:
            print("Программы не найдены в БД!")
            
    except Exception as e:
        print(f"Ошибка подключения к БД: {e}")